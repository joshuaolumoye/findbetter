exports.id=31,exports.ids=[31],exports.modules={6710:(a,b,c)=>{"use strict";c.d(b,{A:()=>f});var d=c(46101);let e={host:process.env.DB_HOST??"127.0.0.1",user:process.env.DB_USER??"nextuser",password:process.env.DB_PASSWORD??"FindBetter!2025",database:process.env.DB_NAME??"insurrance",port:Number(process.env.DB_PORT??3306),waitForConnections:!0,connectionLimit:10,queueLimit:0},f=d.createPool(e)},28303:a=>{function b(a){var b=Error("Cannot find module '"+a+"'");throw b.code="MODULE_NOT_FOUND",b}b.keys=()=>[],b.resolve=b,b.id=28303,a.exports=b},55821:(a,b,c)=>{"use strict";c.d(b,{AD:()=>i,Aq:()=>j,CF:()=>f,E8:()=>e,sE:()=>g,wx:()=>h});var d=c(6710);async function e(a){let b;try{var c;console.log("PRODUCTION: Creating user with insurance data..."),b=await Promise.race([d.A.getConnection(),new Promise((a,b)=>setTimeout(()=>b(Error("Database connection timeout")),1e4))]),await b.execute("SET SESSION wait_timeout = 60"),await b.execute("SET SESSION interactive_timeout = 60"),await b.execute("SET SESSION net_read_timeout = 30"),await b.execute("SET SESSION net_write_timeout = 30"),await b.beginTransaction(),console.log("Checking for existing user:",a.email);let[e]=await b.execute("SELECT id FROM users WHERE email = ? LIMIT 1",[a.email.toLowerCase().trim()]);if(e.length>0)throw await b.rollback(),Error(`Ein Benutzer mit der E-Mail-Adresse ${a.email} existiert bereits`);let f=function(a){if(!a||!/^\d{4}$/.test(a))return"ZH";let b=parseInt(a);return b>=1e3&&b<=1299||b>=1300&&b<=1399||b>=1400&&b<=1499?"VD":b>=1200&&b<=1299?"GE":b>=2e3&&b<=2099?"NE":b>=3e3&&b<=3999?"BE":b>=4e3&&b<=4999?"BL":b>=5e3&&b<=5999?"AG":b>=6e3&&b<=6999?"LU":b>=7e3&&b<=7999?"GR":b>=8e3&&b<=8999?"ZH":b>=9e3&&b<=9999?"SG":"ZH"}(a.postalCode);console.log("Inserting new user...");let[g]=await b.execute(`INSERT INTO users (
        salutation, first_name, last_name, email, phone, birth_date,
        address, postal_code, city, canton, nationality, ahv_number,
        current_insurance_policy_number, insurance_start_date,
        id_document_path, interested_in_consultation, status, 
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW(), NOW())`,[a.salutation,a.firstName.trim(),a.lastName.trim(),a.email.toLowerCase().trim(),a.phone.trim(),a.birthDate,a.address.trim(),a.postalCode,a.city||function(a){if(!a)return"";let b=a.match(/\d{4}\s+([A-Za-zäöüÄÖÜ\s]+)$/);if(b)return b[1].trim();let c=a.split(",");return c.length>1?c[c.length-1].trim().replace(/^\d+\s*/,""):""}(a.address),f,a.nationality||"swiss",a.ahvNumber||null,a.currentInsurancePolicyNumber||null,a.insuranceStartDate||"2025-01-01",a.idDocumentPath||null,a.interestedInConsultation]),h=g.insertId;if(!h)throw Error("Failed to create user - no ID returned");console.log("User created with ID:",h);let i=(c=a.selectedInsurance.premium,Math.round(12*Math.max(0,450-c)));console.log("Creating insurance quote...");let[j]=await b.execute(`INSERT INTO insurance_quotes (
        user_id, search_postal_code, search_birth_date, search_franchise,
        search_accident_coverage, search_current_model, search_current_insurer,
        new_to_switzerland, selected_insurer, selected_tariff_name,
        selected_premium, selected_franchise, selected_accident_inclusion,
        selected_age_group, selected_region, selected_fiscal_year,
        quote_status, annual_savings, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'submitted', ?, NOW(), NOW())`,[h,a.searchCriteria.postalCode,a.searchCriteria.birthDate,a.searchCriteria.franchise,a.searchCriteria.accidentCoverage,a.searchCriteria.currentModel,a.searchCriteria.currentInsurer||"Unknown",a.searchCriteria.newToSwitzerland,a.selectedInsurance.insurer,a.selectedInsurance.tariffName,a.selectedInsurance.premium,a.selectedInsurance.franchise,a.selectedInsurance.accidentInclusion,a.selectedInsurance.ageGroup,a.selectedInsurance.region,a.selectedInsurance.fiscalYear,i]),k=j.insertId;if(!k)throw Error("Failed to create insurance quote");return console.log("Insurance quote created with ID:",k),console.log("Creating compliance record..."),await b.execute(`INSERT INTO user_compliance (
        user_id, quote_id, information_art_45, agb_accepted,
        mandate_accepted, termination_authority, consultation_interest, 
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,[h,k,a.compliance.informationArt45,a.compliance.agbAccepted,a.compliance.mandateAccepted,a.compliance.terminationAuthority,a.compliance.consultationInterest]),await b.execute(`INSERT INTO admin_actions (
        user_id, quote_id, admin_user, action_type, action_details, created_at
      ) VALUES (?, ?, 'system', 'user_created', 'Production user registration completed', NOW())`,[h,k]),await b.commit(),console.log(`PRODUCTION: User created successfully with ID: ${h}, Quote ID: ${k}`),h}catch(a){if(console.error("PRODUCTION: Database error in createUserWithInsurance:",a),b)try{await b.rollback()}catch(a){console.error("Rollback error:",a)}if(a.message.includes("Duplicate entry")||a.message.includes("existiert bereits"))throw Error("Ein Benutzer mit dieser E-Mail-Adresse existiert bereits");if(a.message.includes("timeout")||a.message.includes("connection"))throw Error("Datenbankverbindung unterbrochen. Bitte versuchen Sie es erneut.");if(a.message.includes("Data too long"))throw Error("Eingabedaten zu lang. Bitte k\xfcrzen Sie Ihre Angaben.");else if(a.message.includes("cannot be null"))throw Error("Pflichtfelder fehlen. Bitte pr\xfcfen Sie Ihre Eingaben.");throw a}finally{if(b)try{b.release()}catch(a){console.error("Error releasing connection:",a)}}}async function f(){try{console.log("PRODUCTION: Fetching all users...");let[a]=await Promise.race([d.A.execute(`SELECT 
          u.id,
          u.status,
          CONCAT(u.first_name, ' ', u.last_name) as full_name,
          u.email,
          u.phone,
          u.birth_date,
          u.postal_code,
          u.canton,
          u.created_at as join_date,
          iq.selected_insurer,
          iq.selected_premium,
          iq.annual_savings,
          iq.quote_status,
          CASE 
            WHEN uc.id IS NOT NULL THEN 'Complete'
            ELSE 'Incomplete'
          END as compliance_status
        FROM users u
        LEFT JOIN insurance_quotes iq ON u.id = iq.user_id
        LEFT JOIN user_compliance uc ON u.id = uc.user_id
        ORDER BY u.created_at DESC 
        LIMIT 1000`),new Promise((a,b)=>setTimeout(()=>b(Error("Query timeout")),15e3))]);return console.log(`PRODUCTION: Retrieved ${a.length} users`),a}catch(a){throw console.error("PRODUCTION: Error in getAllUsers:",a),Error("Failed to fetch users from database")}}async function g(a){let b;try{console.log(`PRODUCTION: Fetching user details for ID: ${a}`),b=await Promise.race([d.A.getConnection(),new Promise((a,b)=>setTimeout(()=>b(Error("Connection timeout")),5e3))]);let[c]=await Promise.race([b.execute("SELECT * FROM users WHERE id = ? LIMIT 1",[a]),new Promise((a,b)=>setTimeout(()=>b(Error("User query timeout")),1e4))]);if(0===c.length)throw Error(`User not found with ID: ${a}`);let[e,f,g]=await Promise.all([b.execute("SELECT * FROM insurance_quotes WHERE user_id = ? ORDER BY created_at DESC LIMIT 10",[a]).then(([a])=>a),b.execute("SELECT * FROM user_compliance WHERE user_id = ? ORDER BY created_at DESC LIMIT 10",[a]).then(([a])=>a),b.execute("SELECT * FROM admin_actions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20",[a]).then(([a])=>a)]);return console.log(`PRODUCTION: User details retrieved for ID: ${a}`),{user:c[0],quotes:e,compliance:f,adminActions:g}}catch(a){if(console.error("PRODUCTION: Error in getUserDetails:",a),a.message.includes("timeout"))throw Error("Database query timeout - please try again");throw a}finally{b&&b.release()}}async function h(){try{console.log("PRODUCTION: Fetching dashboard statistics...");let[a]=await Promise.race([d.A.execute(`
        SELECT 
          COUNT(DISTINCT u.id) as total_users,
          COUNT(CASE WHEN u.status = 'pending' THEN 1 END) as pending_users,
          COUNT(CASE WHEN u.status = 'active' THEN 1 END) as active_users,
          COUNT(CASE WHEN u.status = 'rejected' THEN 1 END) as rejected_users,
          COUNT(DISTINCT iq.id) as total_quotes,
          ROUND(AVG(iq.selected_premium), 2) as avg_premium,
          ROUND(SUM(iq.annual_savings), 2) as total_savings
        FROM users u 
        LEFT JOIN insurance_quotes iq ON u.id = iq.user_id
      `),new Promise((a,b)=>setTimeout(()=>b(Error("Stats query timeout")),1e4))]),b=a[0]||{total_users:0,pending_users:0,active_users:0,rejected_users:0,total_quotes:0,avg_premium:0,total_savings:0};return console.log("PRODUCTION: Dashboard statistics retrieved:",b),b}catch(a){return console.error("PRODUCTION: Error in getDashboardStats:",a),{total_users:0,pending_users:0,active_users:0,rejected_users:0,total_quotes:0,avg_premium:0,total_savings:0}}}async function i(){try{let[a]=await Promise.race([d.A.execute("SELECT 1 as health, NOW() as timestamp"),new Promise((a,b)=>setTimeout(()=>b(Error("Health check timeout")),5e3))]),b=a.length>0&&1===a[0].health;return console.log("PRODUCTION: Database health check:",b?"HEALTHY":"UNHEALTHY"),b}catch(a){return console.error("PRODUCTION: Database health check failed:",a),!1}}async function j(a,b){try{console.log(`PRODUCTION: Saving document path for user ${a}: ${b}`),await d.A.execute("UPDATE users SET id_document_path = ?, updated_at = NOW() WHERE id = ?",[b,a])}catch(a){throw console.error("PRODUCTION: Error in saveUserDocument:",a),Error("Failed to save document path")}}},78335:()=>{},96487:()=>{}};