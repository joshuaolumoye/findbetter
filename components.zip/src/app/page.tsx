
import React from 'react';
import PremiumCalculator from '../../components/PremiumCalculator';
import ComparisonResult from '../../components/ComparisonResult';
import FAQ from '../../components/faq';
import Footer from '../../components/Footer';

// Star Icon for Trustpilot rating
const StarIcon = () => (
    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
);

// Green checkmark for Trustpilot section
const GreenCheckIcon = () => (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="10" cy="10" r="10" fill="#00B67A"/>
        <path d="M6 10.5L8.66667 13L14 8" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
);


const TrustpilotRating = () => (
    <div className="inline-flex items-center justify-center space-x-4 bg-white p-3 pr-5 rounded-lg border border-green-200 shadow-sm mx-auto">
        <div className="flex items-center space-x-2">
            <GreenCheckIcon />
            <div className="flex bg-green-500 p-1 rounded-sm">
                <StarIcon />
            </div>
            <span className="font-bold text-gray-800">Trustpilot</span>
        </div>
        <div className="text-left">
            <p className="font-semibold text-gray-700 text-sm">Hervorragend, das ist eines der Merkmale von uns!</p>
            <p className="text-xs text-gray-500">einfach und unkompliziert mehr wollte ich nicht.</p>
        </div>
    </div>
);


export default function Home() {
  return (
    <main className="bg-white min-h-screen font-sans text-gray-900">
     <header className="bg-black border-b border-gray-200 sticky top-0 z-10">
        <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
          <div className="font-extrabold text-xl text-white tracking-tight">FindBetter.ch</div>
          <div className="flex items-center space-x-4">
            {/* <button className="text-gray-500 hover:text-gray-900 p-2">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button> */}
            
            {/* Button with image + text */}
            <button className="flex items-center gap-2 bg-white text-black px-4 py-2 rounded-tl-lg rounded-br-lg text-xs font-light hover:bg-gray-200 transition tracking-wider">
              <img src="../../heart.svg" alt="icon" className="w-5 h-4" />
              <span>KRANKENKASSENRECHNER</span>
            </button>
          </div>
        </nav>
      </header>

      <div className="container mx-auto px-6 py-12 sm:py-16 text-center">
        <h1 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-2">Kein Bock mehr, es dir machen zu lassen?</h1>
        <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">fang an es dir selber zu machen.</h2>
        <p className="max-w-xl mx-auto text-gray-600 mb-8 text-base">
          Der widerwilligste und letzte Krankenkassenvergleich der Schweiz.
          Inklusive Kündigung in nur 4 Schritten.
        </p>

        <TrustpilotRating />
        
        <p className="text-xs text-gray-500 mt-3">4.9 Bewertungen auf Trustpilot</p>

        <div className="mt-20 text-center">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4 leading-tight">Über 1.000 Kunden machen es sich mittlerweile<br/>selber du noch etwa nicht?</h3>
            <p className="text-lg text-gray-600">Probiere es aus!</p>
        </div>
      </div>

      <div className="container mx-auto px-6 pb-20">
        <div className="flex flex-col lg:flex-row justify-center items-start gap-8 relative">
          {/* Decorative Arrows for larger screens */}
          <div className="hidden lg:block absolute top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 -mt-20">
             <svg width="150" height="100" viewBox="0 0 150 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M2 98C27.1667 73.8333 78.2 -1.90001 148 2" stroke="#FFC107" strokeWidth="3" strokeLinecap="round"/>
                <path d="M138 12L148 2L138 2" stroke="#FFC107" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
             </svg>
          </div>
           <div className="hidden lg:block absolute top-1/2 right-1/4 translate-x-1/2 -translate-y-1/2 mt-20">
             <svg width="150" height="100" viewBox="0 0 150 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M148 98C122.833 73.8333 71.8 -1.90001 2 2" stroke="#FFC107" strokeWidth="3" strokeLinecap="round"/>
                <path d="M12 12L2 2L12 2" stroke="#FFC107" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
             </svg>
          </div>
          <PremiumCalculator />
          <ComparisonResult />
        </div>
        
      </div>
      <FAQ />
      <Footer />
    </main>
  );
}

// import PricingPage from '../../components/PricingPage';

// export default function Pricing() {
//   return <PricingPage />;
// }

// import Header from '../../components/Header';
// import HeroSection from '../../components/HeroSection';
// import Testimonials from '../../components/Testimonials';
// import FeatureSectionOne from '../../components/FeatureSectionOne';
// import ProcessStepper from '../../components/ProcessStepper';
// import FeatureSectionTwo from '../../components/FeatureSectionTwo';
// import Footer from '../../components/Footer';
// import InsurancePlans from '../../components/InsurancePlans';
// import ExtraCoverage from '../../components/ExtraCoverage';

// export default function App() {
//   const stepperSteps1 = [
//     'PROJEKT STARTEN',
//     'FILTERN',
//     'AUSWÄHLEN',
//     'PITCH ERHALTEN',
//     'PROJEKT ABWICKLN',
//   ];

//   const stepperSteps2 = [
//     'EINFACH & SCHNELL',
//     'PASSENDE EXPERTEN',
//     'KOSTENLOS',
//     'SICHERE ABWICKLUNG',
//     'TRANSPARENT',
//   ];

//   return (
//     <div className="bg-white min-h-screen font-sans">
//       <Header />
//       <main className="container mx-auto px-4 sm:px-6 lg:px-8">
//         <HeroSection />
//         <Testimonials />
//         <div className="my-16 md:my-24" />
//         <ExtraCoverage />
//         <FeatureSectionOne />
//       </main>
//       <Footer />
//     </div>
//   );
// }