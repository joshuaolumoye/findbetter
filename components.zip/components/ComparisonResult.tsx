import React from 'react';

// Using an SVG for the logo placeholder for better quality
const LogoPlaceholder = () => (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)">
        <circle cx="20" cy="20" r="20" fill="#FFD2A3"/>
        <path d="M12 28V12H14.4V19.2H21.6V12H24V28H21.6V20.8H14.4V28H12Z" fill="#D97706"/>
    </svg>
);


const ComparisonResultItem = ({ provider, plan, price }: { provider: string, plan: string, price: string }) => {
  return (
    <div className="flex items-center justify-between p-3 border border-gray-100 rounded-xl mb-3 hover:shadow-md transition-shadow duration-300">
      <div className="flex items-center space-x-4">
        <LogoPlaceholder />
        <div>
          <p className="font-bold text-gray-800">{provider}</p>
          <p className="text-sm text-gray-500">{plan}</p>
        </div>
      </div>
      <div className="flex items-center space-x-6">
        <p className="font-bold text-lg text-gray-900">{price}</p>
        <button className="bg-gray-900 text-white text-sm font-semibold py-2 px-5 rounded-lg hover:bg-gray-800 transition">
          Anfragen
        </button>
      </div>
    </div>
  );
};

const ComparisonResult = () => {
    const results = [
        { provider: 'Helsana', plan: 'HMO', price: 'CHF 471.35' },
        { provider: 'Helsana', plan: 'Telmed', price: 'CHF 517.15' },
        { provider: 'Helsana', plan: 'Standard', price: 'CHF 521.15' },
    ];

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] w-full max-w-2xl">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Vergleichsergebnisse (3)</h2>
        <div className="flex items-center space-x-2 cursor-pointer text-sm text-gray-600">
            <span>Sortiert nach Preis</span>
            <svg xmlns="[http://www.w3.org/2000/svg](http://www.w3.org/2000/svg)" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
        </div>
      </div>
      <div>
        {results.map((result, index) => (
          <ComparisonResultItem key={index} {...result} />
        ))}
      </div>
    </div>
  );
};

export default ComparisonResult;