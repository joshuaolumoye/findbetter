"use client";
import React from 'react';

const PremiumCalculator = () => {
  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.1)] w-full max-w-sm flex-shrink-0">
      <h2 className="text-xl font-bold text-gray-800 mb-6">Prämien Rechner 2025</h2>
      <form>
        <div className="mb-4">
          <label htmlFor="plz" className="block text-sm font-medium text-gray-500 mb-2">Ihre Angaben</label>
          <input type="text" id="plz" placeholder="Postleitzahl"
            className="w-full px-4 py-3 border border-gray-200 bg-gray-50 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition" />
        </div>
        <div className="mb-4">
          <input
            type="text"
            id="geburtsdatum"
            placeholder="Geburtsdatum"
            // onFocus={(e) => (e.target.type = 'date')}
            // onBlur={(e) => (e.target.type = 'text')}
            className="w-full px-4 py-3 border border-gray-200 bg-gray-50 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
          />
        </div>
        <div className="mb-4">
          <select id="franchise" className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
            <option>Franchise</option>
            <option>300</option>
            <option>500</option>
            <option>1000</option>
            <option>1500</option>
            <option>2000</option>
            <option>2500</option>
          </select>
        </div>
        <div className="mb-4">
          <select id="unfalldeckung" className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
            <option>Unfalldeckung</option>
            <option>Mit Unfalldeckung</option>
            <option>Ohne Unfalldeckung</option>
          </select>
        </div>
        <div className="mb-4">
          <select id="aktuellesModell" className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
            <option>Aktuelles Modell</option>
            <option>Standard</option>
            <option>HMO</option>
            <option>Telmed</option>
          </select>
        </div>
        <div className="mb-6">
          <select id="aktuelleKK" className="w-full px-4 py-3 border border-gray-200 rounded-lg bg-gray-50 text-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
            <option>Aktuelle KK</option>
            <option>Helsana</option>
            <option>Swica</option>
            <option>CSS</option>
          </select>
        </div>
        <button
          type="submit"
          className="w-full bg-gray-900 text-white font-semibold py-3 px-4 rounded-lg hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-900 transition duration-300"
        >
          Vergleich Starten
        </button>
      </form>
    </div>
  );
};

export default PremiumCalculator;
